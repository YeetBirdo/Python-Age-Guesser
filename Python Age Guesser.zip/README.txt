INSTRUCTIONS
When prompted, answer the question. To stop, type "stop".
SOCIALS
YouTube: Yeet Birdo
Discord Server: https://discord.gg/bVKvxmb8En
IMPORTANT
THESE FILES REQUIRE YOU TO INTSALL 7-ZIP AND PYTHON. TO RUN THE FILES THE PASSWORD IS "birdo"